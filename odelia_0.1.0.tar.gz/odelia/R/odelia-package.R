#' @useDynLib odelia, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
